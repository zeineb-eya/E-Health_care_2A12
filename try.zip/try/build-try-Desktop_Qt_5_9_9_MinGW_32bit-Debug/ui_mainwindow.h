/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *Nouvel;
    QWidget *Nouvel_2;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *idd;
    QLineEdit *nom;
    QLineEdit *prenom;
    QWidget *Nouvel1;
    QWidget *ajouter;
    QPushButton *pushButton_2;
    QLabel *label_4;
    QLineEdit *lineEdit_4;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        Nouvel = new QTabWidget(centralwidget);
        Nouvel->setObjectName(QStringLiteral("Nouvel"));
        Nouvel->setGeometry(QRect(60, 40, 651, 451));
        Nouvel_2 = new QWidget();
        Nouvel_2->setObjectName(QStringLiteral("Nouvel_2"));
        pushButton = new QPushButton(Nouvel_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(510, 370, 93, 28));
        label = new QLabel(Nouvel_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 100, 55, 16));
        label_2 = new QLabel(Nouvel_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(40, 200, 55, 16));
        label_3 = new QLabel(Nouvel_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(40, 290, 55, 16));
        idd = new QLineEdit(Nouvel_2);
        idd->setObjectName(QStringLiteral("idd"));
        idd->setGeometry(QRect(180, 100, 113, 22));
        nom = new QLineEdit(Nouvel_2);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(180, 200, 113, 22));
        prenom = new QLineEdit(Nouvel_2);
        prenom->setObjectName(QStringLiteral("prenom"));
        prenom->setGeometry(QRect(180, 290, 113, 22));
        Nouvel->addTab(Nouvel_2, QString());
        Nouvel1 = new QWidget();
        Nouvel1->setObjectName(QStringLiteral("Nouvel1"));
        Nouvel->addTab(Nouvel1, QString());
        ajouter = new QWidget();
        ajouter->setObjectName(QStringLiteral("ajouter"));
        pushButton_2 = new QPushButton(ajouter);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(460, 330, 93, 28));
        label_4 = new QLabel(ajouter);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(60, 170, 55, 16));
        lineEdit_4 = new QLineEdit(ajouter);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(120, 170, 113, 22));
        Nouvel->addTab(ajouter, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        Nouvel->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Nom", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Prenom", Q_NULLPTR));
        Nouvel->setTabText(Nouvel->indexOf(Nouvel_2), QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        Nouvel->setTabText(Nouvel->indexOf(Nouvel1), QApplication::translate("MainWindow", "consulter", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        Nouvel->setTabText(Nouvel->indexOf(ajouter), QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
