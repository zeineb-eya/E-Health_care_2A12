#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "service.h"
#include "medecin.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
  ui->tableView->setModel(Etmp.afficher());
  ui->tableView_2->setModel(etmpp.afficherS());

}



MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked() // bouton ajouter
{
    //recuperation des 3 informations saisies dans les 3 champs
    int id=ui->idd->text().toInt();
    ui->idd->setValidator(new QIntValidator(0,99999999,this));

    QString nom=ui->nom->text();
    QString prenom=ui->prenom->text();
    QString specialite=ui->specialite->text();
    QString tel=ui->tel->text();
    Medecin M(id,nom,prenom,specialite,tel) ;// instancier un objet de la classe medecin en utulisant les info saisies dans l'interface
    bool test=M.ajouter();
    if (test)
      { ui->tableView->setModel(Etmp.afficher()); // actualiser

        QMessageBox :: information (nullptr, QObject::tr("OK"),
        QObject::tr("Ajout effectué\n" "Click cancel to exist\n"), QMessageBox::Cancel);

      }
    else
      {  QMessageBox::critical(nullptr , QObject::tr("NOT OK"),
                             QObject::tr("Ajout non effectué.\n""Click cancel to exist.")
                             ,QMessageBox::Cancel);

      }

}

void MainWindow::on_pushButton_2_clicked()  // bouton supprimer
{int id=ui->lineEdit_4->text().toInt();
    bool test=Etmp.supprimer(id);
    if (test)
      {  ui->tableView->setModel(Etmp.afficher());

        QMessageBox :: information (nullptr, QObject::tr("OK"),
        QObject::tr("Suppression effectué\n" "Click cancel to exist\n"), QMessageBox::Cancel);

      }
    else
      {  QMessageBox::critical(nullptr , QObject::tr("NOT OK"),
                             QObject::tr("Suppression non effectué.\n""Click cancel to exist.")
                             ,QMessageBox::Cancel);

      }


}



void MainWindow::on_pushButton_4_clicked() // bouton ajouter service
{
    //recuperation des 3 informations saisies dans les 3 champs
  int ids=ui->idss->text().toInt();
  ui->idd->setValidator(new QIntValidator(0,99999999,this));


    QString type=ui->type->text();
    QDate date=ui->dateEdit->date();
    QString heure=ui->heure->text();
    QString nom_med=ui->nommed->text();
    QString nom_pat=ui->nompat->text();
    int prix=ui->prix->text().toInt();
    service S(ids,type,date,heure,nom_med,nom_pat,prix) ;// instancier un objet de la classe service en utulisant les info saisies dans l'interface
    bool test=S.ajouterS();
    if (test)
      { ui->tableView_2->setModel(etmpp.afficherS()); // actualiser

        QMessageBox :: information (nullptr, QObject::tr("OK"),
        QObject::tr("Ajout effectué\n" "Click cancel to exist\n"), QMessageBox::Cancel);

      }
    else
      {  QMessageBox::critical(nullptr , QObject::tr("NOT OK"),
                             QObject::tr("Ajout non effectué.\n""Click cancel to exist.")
                             ,QMessageBox::Cancel);

      }

}

void MainWindow::on_pushButton_6_clicked() // bouton supprimer service
{
    int ids=ui->lineEdit_5->text().toInt();
        bool test=etmpp.supprimerS(ids);
        if (test)
          {  ui->tableView_2->setModel(etmpp.afficherS());

            QMessageBox :: information (nullptr, QObject::tr("OK"),
            QObject::tr("Suppression effectué\n" "Click cancel to exist\n"), QMessageBox::Cancel);

          }
        else
          {  QMessageBox::critical(nullptr , QObject::tr("NOT OK"),
                                 QObject::tr("Suppression non effectué.\n""Click cancel to exist.")
                                 ,QMessageBox::Cancel);

          }



}


void MainWindow::on_pushButton_7_clicked() //imprimer
{
    QPrinter printer;
    printer.setPrinterName ("le nom de l'imprimante");
    QPrintDialog dialog(&printer,this);
    if (dialog.exec()== QDialog::Rejected)return;
    ui->tableView->render(&printer);
}

void MainWindow::on_mail_clicked()
{
//to do
}



void MainWindow::on_impression_clicked() //imprimer service
{
    QPrinter printer;
    printer.setPrinterName ("le nom de l'imprimante");
    QPrintDialog dialog(&printer,this);
    if (dialog.exec()== QDialog::Rejected)return;
    ui->tableView_2->render(&printer);
}

void MainWindow::on_rechercher_textChanged(const QString &arg1)
{


        if(ui->rechercher->text() == "")
            {
                ui->tableView->setModel(Etmp.afficher());
            }
            else
            {
                 ui->tableView->setModel(Etmp.rechercher(ui->rechercher->text()));
            }

}



void MainWindow::on_lineEdit_2_textChanged(const QString &arg1) //rechercher service
{
    if(ui->lineEdit_2->text() == "")
        {
            ui->tableView_2->setModel(etmpp.afficherS());
        }
        else
        {
             ui->tableView_2->setModel(etmpp.rechercherS(ui->lineEdit_2->text()));
        }

}

void MainWindow::on_pushButton_3_clicked() //trier medecin
{
    QString critere=ui->Trier->currentText();
        QString mode;
         if (ui->asc->isChecked()==true)
    {
             mode="ASC";
    }
         else if(ui->desc->isChecked()==true)
         {
             mode="DESC";
         }
      ui->tableView->setModel(Etmp.trier(critere,mode));

}

void MainWindow::on_modifier_clicked()
{/*


        int id = ui->id->text.toInt();
        QString nom = ui->nom_medecin->text();
        QString prenom= ui->prenom_medecin->text();
        QString cin= ui->specialite_medecin->text();

        QString promotion =rep ;

        medecin m(id,nom,prenom,specialite,tel);
        bool test =Etmp.modifier(id,nom,prenom,specialite,tel);

        if(test)
        {ui->tableView->setModel(m.afficher());
            QMessageBox::information(nullptr, QObject::tr("modifier un medecin"),
                                     QObject::tr("medecin  modifié.\n"
                                                 "Click Cancel to exit."), QMessageBox::Cancel);
            on_pb_annule_historique_clicked();
        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Modifier un medecin"),
                                  QObject::tr("Erreur !.\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);*/

}




void MainWindow::on_pushButton_8_clicked() //trier service
{
    {
        QString critere=ui->tris_2->currentText();
            QString mode;
             if (ui->asc1->isChecked()==true)
        {
                 mode="ASC";
        }
             else if(ui->desc1->isChecked()==true)
             {
                 mode="DESC";
             }
          ui->tableView_2->setModel(etmpp.trierS(critere,mode));

    }
}
