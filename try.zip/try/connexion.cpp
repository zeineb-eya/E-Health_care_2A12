#include "connexion.h"

connexion::connexion()
{}
bool connexion :: createconnexion()
{db = QSqlDatabase::addDatabase("QODBC");
    bool test = false ;
    db.setDatabaseName("EClinic");//inserer le nom de la source de données ODBC
    db.setUserName("system");//inserer nom de l'utilisateur
    db.setPassword("azerty123");//inserer mot de passe de cet utilisateur
    if (db.open()) test = true ;
    return  test ;
}
void connexion:: closeconnexion(){db.close();}
